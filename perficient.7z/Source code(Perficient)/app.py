# Hello and welcome to the "app.py", the Python file that is responsible for making the website viewable.
# In this source code, you will find the use of Flask
# You might be wondering, why Flask is even used if the form isn't responsive. Well, Flask serves the entire website. Those endpoints are responsible for being able to navigate with click of a button. That is how Flask is used. Well, the same could be done in HTML but in Flask, it required less lines
# If you want to run the source code in local env, plz follow guidelines in README.md and follow them step-by-step
from flask import Flask, render_template

app = Flask(__name__, template_folder='.')

# Below are the endpoints for every webpage
@app.route("/")
def hello_world():
    return render_template('index.html')

@app.route("/about")
def about():
    return render_template('about.html')
    
@app.route("/contact")
def contact():
    return render_template('contact.html')

@app.route("/prices")
def prices():
    return render_template('prices.html')

@app.route("/help")
def help():
    return render_template('help.html')


if __name__ == '__main__':
    app.run(port=5000, debug=True)